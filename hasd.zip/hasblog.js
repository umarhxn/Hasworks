function scrollToSection(about) {
  document.getElementById(about).scrollIntoView({ behavior: 'smooth' });
  
}
function scrollToSection(passion) {
  document.getElementById(passion).scrollIntoView({ behavior: 'smooth' });
}
function scrollToSection(education) {
  document.getElementById(education).scrollIntoView({ behavior: 'smooth' });
}



window.addEventListener('scroll', () => {
  const textElements = document.querySelectorAll('.text, .texting ,.background');
  textElements.forEach((element) => {
    const rect = element.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      element.classList.add('show');
    } else {
      element.classList.remove('show');
    }
  });
});

// trigger animation on page load
window.addEventListener('DOMContentLoaded', () => {
  const textElements = document.querySelectorAll('.text, .texting, .background');
  textElements.forEach((element) => {
    const rect = element.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) {
      element.classList.add('show');
    }
  });
});


window.addEventListener('scroll', () => {
  const header = document.querySelector('.header ');
  if (window.scrollY > 100) {
    header.classList.add('scrolled');
  } else {
    header.classList.remove('scrolled');
  }
});
 



